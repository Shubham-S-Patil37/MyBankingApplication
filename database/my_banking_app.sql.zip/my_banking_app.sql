-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 07, 2020 at 05:52 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `my_banking_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `block_status`
--

CREATE TABLE IF NOT EXISTS `block_status` (
  `id` varchar(30) default NULL,
  `flag` int(11) default NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `block_status`
--

INSERT INTO `block_status` (`id`, `flag`) VALUES
('admin', 0),
('shubham_patil', 1);

-- --------------------------------------------------------

--
-- Table structure for table `log_in`
--

CREATE TABLE IF NOT EXISTS `log_in` (
  `id` varchar(30) default NULL,
  `password` varchar(50) default NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `log_in`
--

INSERT INTO `log_in` (`id`, `password`) VALUES
('admin', 'admin'),
('shubham_patil', 'shubham');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `acc_no` varchar(15) NOT NULL,
  `balance` varchar(10) NOT NULL,
  `name` varchar(50) default NULL,
  `id` varchar(30) NOT NULL default '',
  `e_mail_id` varchar(50) default NULL,
  `upi_id` varchar(50) default NULL,
  `mobile_no` varchar(11) default NULL,
  `aadhar1` int(11) default NULL,
  `aadhar2` int(11) default NULL,
  `aadhar3` int(11) default NULL,
  `date` int(11) default NULL,
  `month` int(11) default NULL,
  `year` int(11) default NULL,
  `img_path` varchar(200) default NULL,
  `address` varchar(300) default NULL,
  `address1` varchar(300) default NULL,
  `address2` varchar(300) default NULL,
  `save_pass` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`acc_no`, `balance`, `name`, `id`, `e_mail_id`, `upi_id`, `mobile_no`, `aadhar1`, `aadhar2`, `aadhar3`, `date`, `month`, `year`, `img_path`, `address`, `address1`, `address2`, `save_pass`) VALUES
('111222333', '10,000', 'admin', 'admin', 'admin@gmail.com', 'admin@myBank', '9960262933', 1111, 2222, 3333, 20, 80, 1998, 'C:\\Users\\Lenovo\\Desktop\\my_png.png', '65 A laxmi narayan nagar karvand naka shirpur\ntal shirpur dist dhule ', 'shirpur dhule', 'dhule maharashtra', 0),
('1122334455', '8,000', 'Shubham Patil', 'shubham_patil', 'patil.shubham1212@gmail.com', 'patil.shubham@myBank', '9960262933', 123, 456, 678, 20, 80, 1998, 'E:\\study\\java\\netbeans\\my_banking_application\\src\\images\\profile_img\\profile.png', 'add', 'add', 'add', 0);

-- --------------------------------------------------------

--
-- Table structure for table `setting_pnl_table`
--

CREATE TABLE IF NOT EXISTS `setting_pnl_table` (
  `id` varchar(30) default NULL,
  `select_language` varchar(20) default NULL,
  `profile_status` varchar(40) default NULL,
  `dark_mode` int(11) default NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting_pnl_table`
--

